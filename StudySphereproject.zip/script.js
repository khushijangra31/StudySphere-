// ======================
// CGPA Calculator
// ======================

function calcCGPA() {
    let g1 = parseFloat(document.getElementById("g1").value) || 0;
    let g2 = parseFloat(document.getElementById("g2").value) || 0;

    let cgpa = ((g1 + g2) / 2).toFixed(2);

    document.getElementById("cgpaResult").innerHTML =
        `Your CGPA: <strong>${cgpa}</strong>`;
}

// ======================
// Attendance Calculator
// ======================

function calcAttendance() {

    let attended = parseFloat(document.getElementById("attended").value) || 0;
    let total = parseFloat(document.getElementById("total").value) || 0;

    if (total <= 0) {
        document.getElementById("attendanceResult").innerText =
            "Please enter valid values";
        return;
    }

    let percentage = ((attended / total) * 100).toFixed(2);

    document.getElementById("attendanceResult").innerHTML =
        `Attendance: <strong>${percentage}%</strong>`;
}

// ======================
// Dark Mode
// ======================

const themeBtn = document.getElementById("themeBtn");

if (themeBtn) {

    themeBtn.addEventListener("click", () => {

        document.body.classList.toggle("dark");

        if (document.body.classList.contains("dark")) {
            themeBtn.innerText = "☀️ Light Mode";
        } else {
            themeBtn.innerText = "🌙 Dark Mode";
        }

    });

}

// ======================
// Pomodoro Timer
// ======================

let time = 1500;
let timer;
let running = false;

function updateTimer() {

    let min = Math.floor(time / 60);
    let sec = time % 60;

    document.getElementById("timer").innerText =
        `${min}:${sec < 10 ? '0' : ''}${sec}`;
}

function startTimer() {

    if (running) return;

    running = true;

    timer = setInterval(() => {

        if (time > 0) {
            time--;
            updateTimer();
        } else {
            clearInterval(timer);
            alert("🎉 Study Session Completed!");
            running = false;
        }

    }, 1000);
}

function pauseTimer() {

    clearInterval(timer);
    running = false;
}

function resetTimer() {

    clearInterval(timer);

    time = 1500;

    running = false;

    updateTimer();
}

// ======================
// Notes Saver
// ======================

function saveNotes() {

    let notes = document.getElementById("notes").value;

    localStorage.setItem("studySphereNotes", notes);

    document.getElementById("savedMsg").innerText =
        "✅ Notes Saved Successfully";
}

// ======================
// Goal Tracker
// ======================

function addGoal() {

    let input = document.getElementById("goalInput");

    let goal = input.value.trim();

    if (goal === "") return;

    let goals =
        JSON.parse(localStorage.getItem("goals")) || [];

    goals.push(goal);

    localStorage.setItem(
        "goals",
        JSON.stringify(goals)
    );

    input.value = "";

    loadGoals();
}

function deleteGoal(index) {

    let goals =
        JSON.parse(localStorage.getItem("goals")) || [];

    goals.splice(index, 1);

    localStorage.setItem(
        "goals",
        JSON.stringify(goals)
    );

    loadGoals();
}

function loadGoals() {

    let goalList =
        document.getElementById("goalList");

    if (!goalList) return;

    goalList.innerHTML = "";

    let goals =
        JSON.parse(localStorage.getItem("goals")) || [];

    goals.forEach((goal, index) => {

        goalList.innerHTML += `
        <li>
            ${goal}
            <button class="deleteBtn"
            onclick="deleteGoal(${index})">
            Delete
            </button>
        </li>
        `;
    });
}

// ======================
// Study Streak
// ======================

function markStudy() {

    let streak =
        parseInt(localStorage.getItem("streak")) || 0;

    streak++;

    localStorage.setItem("streak", streak);

    document.getElementById("streakCount").innerText =
        streak + " Days";
}

function loadStreak() {

    let streak =
        parseInt(localStorage.getItem("streak")) || 0;

    let streakElement =
        document.getElementById("streakCount");

    if (streakElement) {
        streakElement.innerText =
            streak + " Days";
    }
}

// ======================
// Exam Countdown
// ======================

function calculateCountdown() {

    let examDate =
        document.getElementById("examDate").value;

    if (!examDate) return;

    let today = new Date();

    let exam = new Date(examDate);

    let diff = exam - today;

    let days =
        Math.ceil(diff / (1000 * 60 * 60 * 24));

    document.getElementById(
        "countdownResult"
    ).innerText =
        days + " Days Remaining";
}

// ======================
// Advanced CGPA
// ======================

function advancedCGPA() {

    let input =
        document.getElementById("semesterMarks").value;

    let values =
        input.split(",")
             .map(Number)
             .filter(num => !isNaN(num));

    if (values.length === 0) {
        document.getElementById(
            "advancedResult"
        ).innerText =
            "Enter valid SGPA values";
        return;
    }

    let sum = 0;

    values.forEach(value => {
        sum += value;
    });

    let cgpa =
        (sum / values.length).toFixed(2);

    document.getElementById(
        "advancedResult"
    ).innerText =
        "Overall CGPA: " + cgpa;
}

// ======================
// Progress Tracker
// ======================

function updateProgress() {

    let progressBar =
        document.getElementById("progressBar");

    if (!progressBar) return;

    let value = progressBar.value;

    document.getElementById(
        "progressText"
    ).innerText =
        value + "% Completed";
}

// ======================
// On Load
// ======================

window.onload = () => {

    let notesBox =
        document.getElementById("notes");

    if (notesBox) {
        notesBox.value =
            localStorage.getItem(
                "studySphereNotes"
            ) || "";
    }

    updateTimer();
    loadGoals();
    loadStreak();
    updateProgress();
};